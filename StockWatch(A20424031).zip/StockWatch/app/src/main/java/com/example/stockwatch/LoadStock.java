package com.example.stockwatch;

import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LoadStock extends AsyncTask<String,Void,String> {
    private MainActivity mainActivity;
    private static final String DATAURL_1 = "https://api.iextrading.com/1.0/stock/";
    private static final String DATAURL_2 = "/quote?displayPercent=true";

    public LoadStock(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    protected String doInBackground(String... strings) {
        String API_URL = DATAURL_1 + strings[0] + DATAURL_2;
        Uri uri = Uri.parse(API_URL);
        String url_string = uri.toString();
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(url_string);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            InputStream inputStream = connection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while((line = bufferedReader.readLine())!=null){
                stringBuilder.append(line).append("\n");
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Stocks stock = jsonToMap(s);
        mainActivity.placeStock(stock);
    }

    private Stocks jsonToMap(String s) {
        Stocks ss = new Stocks();
        try {
            JSONObject j_obj = new JSONObject(s);
            String symbol = j_obj.getString("symbol");
            String name = j_obj.getString("companyName");
            double price = j_obj.getDouble("latestPrice");
            double priceChange = j_obj.getDouble("change");
            double changePercentage = j_obj.getDouble("changePercent");

            ss.setCompanyName(name);
            ss.setCompanySymbol(symbol);
            ss.setPrice(price);
            ss.setPriceChange(priceChange);
            ss.setChangePercentage(changePercentage);
            return ss;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}

