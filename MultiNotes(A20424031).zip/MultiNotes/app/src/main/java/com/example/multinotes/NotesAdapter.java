package com.example.multinotes;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesViewHolder> {
    private List<Notes> notesList;
    private MainActivity mainAct;

    public NotesAdapter(List<Notes> notesList, MainActivity mainAct) {
        this.notesList = notesList;
        this.mainAct = mainAct;
    }


    @NonNull
    @Override
    public NotesViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.notes_list, viewGroup, false);

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);

        return new NotesViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NotesViewHolder notesViewHolder, int i) {
        Notes notes = notesList.get(i);
        notesViewHolder.title.setText(notes.getTitle());
        notesViewHolder.date.setText(notes.getDate());
        if(notes.getDesc().length() > 80){
            String new_Note = notes.getDesc().substring(0, 79);
            new_Note = new_Note.concat("...");
            notesViewHolder.desc.setText(new_Note);
        }
        else {
            notesViewHolder.desc.setText(notes.getDesc());
        }
    }

    @Override
    public int getItemCount() {
        mainAct.getSupportActionBar().setTitle("Multinotes ("+notesList.size()+")");
        return notesList.size();
    }
}
