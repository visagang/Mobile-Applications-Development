package com.example.multinotes;

import java.io.Serializable;

public class Notes implements Serializable {
private String title;
private String desc;
public String date;
public Notes(){

}

    public String getTitle() {
        return title;
    }
    public Notes(String title, String note, String date) {
        this.title = title;
        this.desc = note;
        this.date = date;
    }


    public String getDesc() {

    return desc;
    }

    public void setTitle(String title) {

    this.title = title;
    }
    public void setDesc(String desc) {

    this.desc = desc;
    }
    public String getDate() {

    return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

}
