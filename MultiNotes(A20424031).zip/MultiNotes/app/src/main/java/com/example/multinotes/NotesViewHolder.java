package com.example.multinotes;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class NotesViewHolder extends RecyclerView.ViewHolder {
public TextView title;
public TextView desc;
public TextView date;

public NotesViewHolder(View view){
    super(view);
    title=view.findViewById(R.id.textView4);
    desc=view.findViewById(R.id.textView5);
    date=view.findViewById(R.id.textView6);

}
}
