package com.example.converter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private EditText indegrees;
    private TextView outdegrees;
    private TextView display;
    private TextView outdisplay;
    private TextView values;
    private RadioButton rb1;
    private RadioButton rb2;
    String finaloutput="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        indegrees=findViewById(R.id.editText);
        outdegrees=findViewById(R.id.textView5);
        values=findViewById(R.id.textView6);
        rb1=findViewById(R.id.radioButton);
        rb2=findViewById(R.id.radioButton2);
        display=findViewById(R.id.textView2);
        outdisplay=findViewById(R.id.textView3);
        values.setMovementMethod(new ScrollingMovementMethod());
        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText("Farenheit Degrees:");
                outdisplay.setText("Celsuis Degrees:");
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText("Celsius Degrees:");
                outdisplay.setText("Farenheit Degrees:");
            }
        });

    }
    public void buttonPressed(View v){
        String temp=indegrees.getText().toString();
        double tempd=Double.parseDouble(temp);
        double output;

        if(rb1.isChecked()==true){
            output=(tempd-32.0)/1.8;
            outdegrees.setText(String.format("%.1f",output));
            finaloutput=temp+" F ==> "+String.format("%.1f",output)+" C \n"+finaloutput;
            values.setText(finaloutput);
        }
        if(rb2.isChecked()==true){
            //display.setText("Celsius Degrees:");
            output=(tempd*1.8)+32;
            outdegrees.setText(String.format("%.1f",output));
            finaloutput=temp+" C ==> "+String.format("%.1f",output)+" F \n"+finaloutput;
            values.setText(finaloutput);
        }


    }
    public void buttonClear(View v){
        values.setText("");
        finaloutput="";
        outdegrees.setText("");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("HISTORY",values.getText().toString());
        outState.putString("VALUES",outdegrees.getText().toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        String x;
        values.setText(savedInstanceState.getString("HISTORY"));
        finaloutput=savedInstanceState.getString("HISTORY");
        outdegrees.setText(savedInstanceState.getString("VALUES"));
    }
}
